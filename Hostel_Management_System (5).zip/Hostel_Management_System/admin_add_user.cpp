#include "admin_add_user.h"
#include "ui_admin_add_user.h"
#include<QMessageBox>
#include<QFile>
#include<QTextStream>
#include<QDebug>
#include"admin_dashboard.h"

class admin_dashboard;
admin_add_student::admin_add_student(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::admin_add_student)
{
    ui->setupUi(this);
       this->setStyleSheet("background-color:#36454F;");
}

admin_add_student::~admin_add_student()
{
    delete ui;
}

void admin_add_student::on_pushButton_clicked()
{
    QString name = ui->name ->text();
    QString father=ui->fathername->text();
    QString cnic = ui->cnicnumber->text();
    QString addres = ui->address->text();
    QString cont = ui->contactno->text();
    QString profession =ui->profession->currentText();
    QDate dob = ui->Date->date();
    QString dobStr = dob.toString("dd-MM-yyyy");
    if(name.length()<= 3 ||father.length()<=3 || cnic.length()<=4 || addres.length()<=5 || cont.length()<=4 )
    {

 QMessageBox::warning(this,"Error","plz enter Correct details");

    }
    else
    {
    QFile file("C:/Users/abdul/OneDrive/Desktop/Hostel_Management_System/studentdetail.txt");
    if(!file.open(QIODevice::Append | QIODevice::Text))
    {
        QMessageBox::warning(this,"Error","Cannot open file");
        return;
    }
    else
    {
    QTextStream out(&file);
    out<<name<<"|"<<father<<"|"<<cnic<<"|"<<addres<<"|"<<cont<<"|"<<profession<<"|"<< dobStr<<"\n" ;
    file.close();
     QMessageBox::information(this,"Success","Registered Successfully");


    }}
}


void admin_add_student::on_pushButton_2_clicked()
{
    hide();
    dash = new admin_dashboard(this);
    dash->show();
}


