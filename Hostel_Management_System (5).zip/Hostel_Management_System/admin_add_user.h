#ifndef ADMIN_ADD_USER_H
#define ADMIN_ADD_USER_H


#include <QMainWindow>
class admin_dashboard;

namespace Ui {
class admin_add_student;
}

class admin_add_student : public QMainWindow
{
    Q_OBJECT

public:
    explicit admin_add_student(QWidget *parent = nullptr);
    ~admin_add_student();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::admin_add_student *ui;
    admin_dashboard * dash;

};

#endif // ADMIN_ADD_USER_H
