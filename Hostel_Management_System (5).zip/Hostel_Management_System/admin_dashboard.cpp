#include "admin_dashboard.h"
#include "ui_admin_dashboard.h"
#include<QMessageBox>
#include<QObject>
#include<QFile>
#include<QTextStream>
#include<QDebug>
#include"logos.h"
admin_dashboard::admin_dashboard(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::admin_dashboard)
{
    ui->setupUi(this);
        this->setStyleSheet("background-color:#36454F;");
}

admin_dashboard::~admin_dashboard()
{
    delete ui;
}

void admin_dashboard::on_pushButton_7_clicked()
{

        QMessageBox::StandardButton reply;

        reply = QMessageBox::question(this,"Message", "Do you really want to logout?",QMessageBox::Yes | QMessageBox::No);

        if (reply == QMessageBox::Yes) {
            // mainpage = new main_page(this);
            //            mainpage->show();
            log = new logos(this);
            log->show();

            this->close();

        } else {
            return;
        }



}





void admin_dashboard::on_addstudent_clicked()
{
    hide();
    admin_add = new admin_add_student(this);
    admin_add->show();

}


void admin_dashboard::on_Deletestudent_clicked()
{
    hide();
    admin_delete = new admin_delete_user(this);
    admin_delete->show();
}


void admin_dashboard::on_updatemealmenu_clicked()
{
    hide();
    admin_meal = new admin_update_meal(this);
    admin_meal->show();

}


void admin_dashboard::on_viewcomplains_clicked()
{
    hide();
    admin_complains = new admin_view_complains(this);
    admin_complains->show();

}


void admin_dashboard::on_viewallstudentdetails_clicked()
{
    hide();
    admin_detail = new admin_view_details(this);
    admin_detail->show();
}

