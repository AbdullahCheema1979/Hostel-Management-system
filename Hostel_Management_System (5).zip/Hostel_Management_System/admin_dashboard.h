#ifndef ADMIN_DASHBOARD_H
#define ADMIN_DASHBOARD_H
#include "admin_add_user.h"
#include "admin_delete_user.h"
#include "admin_update_meal.h"
#include "admin_view_complains.h"
#include "admin_view_details.h"
// #include "logos.h"
class logos;
// class main_page;
#include <QMainWindow>
class admin_delete_user;
class admin_add_user;

namespace Ui {
class admin_dashboard;
}

class admin_dashboard : public QMainWindow
{
    Q_OBJECT

public:
    explicit admin_dashboard(QWidget *parent = nullptr);
    ~admin_dashboard();

private slots:
    void on_pushButton_7_clicked();

    void on_pushButton_2_clicked();

    void on_addstudent_clicked();

    void on_Deletestudent_clicked();

    void on_updatemealmenu_clicked();

    void on_viewcomplains_clicked();

    void on_viewallstudentdetails_clicked();

private:
    Ui::admin_dashboard *ui;
    admin_add_student * admin_add;
    admin_delete_user * admin_delete;
    admin_update_meal * admin_meal;
    admin_view_complains * admin_complains;
    admin_view_details * admin_detail;
     // main_page * mainpage;
    logos * log;





};

#endif // ADMIN_DASHBOARD_H
