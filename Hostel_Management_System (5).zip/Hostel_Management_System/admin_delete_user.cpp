#include "admin_delete_user.h"
#include "ui_admin_delete_user.h"
#include"admin_dashboard.h"

#include<QMessageBox>
#include<QFile>
#include<QTextStream>
#include<QDebug>

admin_delete_user::admin_delete_user(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::admin_delete_user)
{
    ui->setupUi(this);
       this->setStyleSheet("background-color:#36454F;");
}

admin_delete_user::~admin_delete_user()
{
    delete ui;
}

void admin_delete_user::on_pushButton_clicked()
{

    QString deleteCnic = ui->cnic->text();
    if(deleteCnic.length() < 1)
    {
         QMessageBox::warning(this, "Error", "Data Cannot be empty");
    }
    else
    {
    QString filePath = "C:/Users/abdul/OneDrive/Desktop/Hostel_Management_System/studentdetail.txt";

    QFile file(filePath);
    QFile tempFile("temp.txt");


    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot open file");
        return;
    }

    if (!tempFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot create temp file");
        return;
    }

    QTextStream in(&file);
    QTextStream out(&tempFile);

    bool deleted = false;

    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList data = line.split("|");

        // Assuming CNIC is stored at index 2
        if (data.size() > 2 && data[2] == deleteCnic) {
            deleted = true;
            continue;
        }

        out << line << "\n";
    }

    file.close();
    tempFile.close();

    if (deleted) {
        file.remove();
        tempFile.rename(filePath);
        QMessageBox::warning(this, "sucess", "Data deleted  sucessfully");
    } else {
        tempFile.remove();
       QMessageBox::warning(this, "invalid ", "No record found with this cnic");
    }
    }

}

void admin_delete_user::on_pushButton_2_clicked()
{
    hide();
    dashboeard = new admin_dashboard(this);
    dashboeard->show();
}

