#ifndef ADMIN_DELETE_USER_H
#define ADMIN_DELETE_USER_H


#include <QMainWindow>
class admin_dashboard;

namespace Ui {
class admin_delete_user;
}

class admin_delete_user : public QMainWindow
{
    Q_OBJECT

public:
    explicit admin_delete_user(QWidget *parent = nullptr);
    ~admin_delete_user();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::admin_delete_user *ui;
    admin_dashboard * dashboeard;
};

#endif // ADMIN_DELETE_USER_H
