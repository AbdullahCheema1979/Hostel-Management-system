#include "admin_login.h"
#include "ui_admin_login.h"

#include<QMessageBox>
#include<QFile>
#include<QTextStream>
#include<QDebug>

admin_login::admin_login(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::admin_login)
{
    ui->setupUi(this);
       this->setStyleSheet("background-color:#36454F;");
}

admin_login::~admin_login()
{
    delete ui;
}

void admin_login::on_pushButton_2_clicked()
{
      bool found=false;


    QString enteruser=ui->entered_user->text();
    QString enterpass=ui->entered_pass->text();
    QFile file("C:/Users/abdul/OneDrive/Desktop/Hostel_Management_System/adminlogin.txt");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QMessageBox::warning(this,"Error","Cannot open file!");
        return;
    }
    else
    {
        QTextStream in(&file);

        while(!in.atEnd())
        {
            QString line = in.readLine();
            QStringList data = line.split("|");
            if(data.size() >=4)
            {
                QString savedUsername = data[0];
                QString savedCnic = data[1];
                QString savedEmail = data[2];
                QString savedPassword = data[3];
                if((enteruser == savedCnic && enterpass == savedPassword))
                {
                    found=true;
                    break;
                }
            }
        }
    }
    file.close();
    if(found)
    {    hide();
        dashboard_admin = new admin_dashboard(this);
        dashboard_admin ->show();


    }

    else
    {
QMessageBox::information(this,"Error","Invalid craditionals!");

    }

}

