#ifndef ADMIN_LOGIN_H
#define ADMIN_LOGIN_H
#include "admin_dashboard.h"
#include <QMainWindow>

namespace Ui {
class admin_login;
}

class admin_login : public QMainWindow
{
    Q_OBJECT

public:
    explicit admin_login(QWidget *parent = nullptr);
    ~admin_login();

private slots:
    void on_pushButton_2_clicked();

private:
    Ui::admin_login *ui;
       admin_dashboard * dashboard_admin;
};

#endif // ADMIN_LOGIN_H
