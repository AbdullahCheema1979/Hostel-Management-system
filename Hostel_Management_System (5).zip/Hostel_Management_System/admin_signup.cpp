#include "admin_signup.h"
#include "ui_admin_signup.h"
#include<QString>
#include<QMessageBox>
#include<QFile>
#include<QTextStream>
#include<QDebug>


admin_signup::admin_signup(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::admin_signup)
{
    ui->setupUi(this);
       this->setStyleSheet("background-color:#36454F;");

}

admin_signup::~admin_signup()
{
    delete ui;
}

void admin_signup::on_pushButton_clicked()
{

        QString username = ui->name_lineEdit->text();
        QString Cnic = ui->cnic_lineEdit->text();
        QString email = ui->email_lineEdit->text();
        QString password = ui->password_lineEdit->text();

        if(password.length() < 8)
        {
            QMessageBox ::warning(this, "Error", "Cannot open file!");

        }
else
        {

        QFile file("C:/Users/abdul/OneDrive/Desktop/Hostel_Management_System/adminlogin.txt");
        if(!file.open(QIODevice::Append | QIODevice::Text))
        {
            QMessageBox::warning(this, "Error", "Cannot open file!");
            return;
        }
else
        {
        QTextStream out(&file);
        out << username << "|" << Cnic << "|" << email << "|" << password << "\n";

        file.close();
   QMessageBox::information(this, "Success", "Signup sucessfully");

        hide();
        login_admin = new admin_login(this);
        login_admin->show();
        }

        }

}

