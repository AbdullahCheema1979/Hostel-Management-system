#ifndef ADMIN_SIGNUP_H
#define ADMIN_SIGNUP_H
#include "admin_login.h"
#include <QMainWindow>

namespace Ui {
class admin_signup;
}

class admin_signup : public QMainWindow
{
    Q_OBJECT

public:
    explicit admin_signup(QWidget *parent = nullptr);
    ~admin_signup();

private slots:
    void on_pushButton_clicked();

private:
    Ui::admin_signup *ui;
    admin_login * login_admin;
};

#endif // ADMIN_SIGNUP_H
