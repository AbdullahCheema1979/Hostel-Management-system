#include "admin_update_meal.h"
#include "ui_admin_update_meal.h"
#include<QMessageBox>
#include<QFile>
#include<QTextStream>
#include<QDebug>
#include"admin_dashboard.h";
admin_update_meal::admin_update_meal(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::admin_update_meal)
{
    ui->setupUi(this);
       this->setStyleSheet("background-color:#36454F;");
}

admin_update_meal::~admin_update_meal()
{
    delete ui;
}

void admin_update_meal::on_pushButton_clicked()
{
    QString monday = ui->MondaycomboBox->currentText();
    QString tuesday = ui->TuesdaycomboBox->currentText();
    QString wednesday = ui->WdnesdaycomboBox->currentText();
    QString thursday = ui->ThursdaycomboBox->currentText();
    QString friday = ui->FridaycomboBox->currentText();
    QString saturday = ui->SaturdaycomboBox->currentText();
    QString sunday = ui->SundaycomboBox->currentText();
    QFile file("C:/Users/abdul/OneDrive/Desktop/Hostel_Management_System/meal.txt");
    if(!file.open(QIODevice::Append | QIODevice::Text))
    {
        QMessageBox::warning(this,"Error","Cannot open file!");
    }
    else
    {
    QTextStream out(&file);
    out<<monday<<"\n";
    out<<tuesday<<"\n";
    out<<wednesday<<"\n";
    out<<thursday<<"\n";
    out<<friday<<"\n";
    out<<saturday<<"\n";
    out<<sunday<<"\n";
    file.close();
    QMessageBox::information(this,"Success","Meal changed sucessfully");
    }
}


void admin_update_meal::on_pushButton_2_clicked()
{   hide();
    dash = new admin_dashboard();
    dash->show();
}

