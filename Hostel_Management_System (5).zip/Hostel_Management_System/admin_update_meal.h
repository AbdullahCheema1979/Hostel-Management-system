#ifndef ADMIN_UPDATE_MEAL_H
#define ADMIN_UPDATE_MEAL_H

#include <QMainWindow>
class admin_dashboard;
namespace Ui {
class admin_update_meal;
}

class admin_update_meal : public QMainWindow
{
    Q_OBJECT

public:
    explicit admin_update_meal(QWidget *parent = nullptr);
    ~admin_update_meal();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::admin_update_meal *ui;
    admin_dashboard * dash;
};

#endif // ADMIN_UPDATE_MEAL_H
