#include "admin_view_complains.h"
#include "ui_admin_view_complains.h"
#include<QFile>
#include<QTextStream>
#include<QDebug>
#include<QMessageBox>
#include"admin_dashboard.h"

admin_view_complains::admin_view_complains(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::admin_view_complains)
{
    ui->setupUi(this);
       this->setStyleSheet("background-color:#36454F;");
}

admin_view_complains::~admin_view_complains()
{
    delete ui;
}

void admin_view_complains::on_pushButton_clicked()
{
    QFile file("C:/Users/abdul/OneDrive/Desktop/Hostel_Management_System/complains.txt");

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot open file");
        return;
    }

    QString message = file.readAll();
    file.close();

    ui->textEdit->setPlainText(message);

}







void admin_view_complains::on_pushButton_2_clicked()
{hide();
    dashe = new admin_dashboard(this);
    dashe->show();
}

