#ifndef ADMIN_VIEW_COMPLAINS_H
#define ADMIN_VIEW_COMPLAINS_H

#include <QMainWindow>
class admin_dashboard;
namespace Ui {
class admin_view_complains;
}

class admin_view_complains : public QMainWindow
{
    Q_OBJECT

public:
    explicit admin_view_complains(QWidget *parent = nullptr);
    ~admin_view_complains();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::admin_view_complains *ui;
    admin_dashboard * dashe;
};

#endif // ADMIN_VIEW_COMPLAINS_H
