#include "admin_view_details.h"
#include "ui_admin_view_details.h"
#include<QFile>
#include<QTextStream>
#include<QDebug>
#include<QMessageBox>
#include"admin_dashboard.h"

admin_view_details::admin_view_details(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::admin_view_details)
{
    ui->setupUi(this);
       this->setStyleSheet("background-color:#36454F;");
}

admin_view_details::~admin_view_details()
{
    delete ui;

}

void admin_view_details::on_pushButton_clicked()
{
    QFile file("C:/Users/abdul/OneDrive/Desktop/Hostel_Management_System/studentdetail.txt");

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot open file");
        return;
    }

    QTextStream in(&file);

    // Set table headers
    QStringList headers;
    headers << "Name" << "Father" << "CNIC" << "Address"
            << "Contact" << "Profession" << "DOB";

    ui->tableWidget->setColumnCount(headers.size());
    ui->tableWidget->setHorizontalHeaderLabels(headers);

    ui->tableWidget->setRowCount(0);

    int row = 0;
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList data = line.split("|");

        if (data.size() < 7)
            continue;

        ui->tableWidget->insertRow(row);

        for (int col = 0; col < 7; col++) {
            ui->tableWidget->setItem(row, col, new QTableWidgetItem(data[col]));
        }

        row++;
    }

    file.close();
}


void admin_view_details::on_pushButton_2_clicked()
{ hide();
    da = new admin_dashboard(this);
    da->show();
}

