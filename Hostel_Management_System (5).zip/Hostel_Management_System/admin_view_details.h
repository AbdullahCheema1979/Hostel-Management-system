#ifndef ADMIN_VIEW_DETAILS_H
#define ADMIN_VIEW_DETAILS_H

#include <QMainWindow>
class admin_dashboard;
namespace Ui {
class admin_view_details;
}

class admin_view_details : public QMainWindow
{
    Q_OBJECT

public:
    explicit admin_view_details(QWidget *parent = nullptr);
    ~admin_view_details();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::admin_view_details *ui;
    admin_dashboard * da;
};

#endif // ADMIN_VIEW_DETAILS_H
