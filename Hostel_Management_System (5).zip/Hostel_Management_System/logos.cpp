#include "logos.h"
#include "ui_logos.h"


logos::logos(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::logos)
{
    ui->setupUi(this);

       this->setStyleSheet("background-color:#D5DDE2;");
}

logos::~logos()
{
    delete ui;

}

void logos::on_pushButton_clicked()
{
    hide();
    page_main = new Main_page(this);
    page_main->show();
}

