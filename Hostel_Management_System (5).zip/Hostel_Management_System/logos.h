#ifndef LOGOS_H
#define LOGOS_H
#include"main_page.h"
#include <QMainWindow>

namespace Ui {
class logos;
}

class logos : public QMainWindow
{
    Q_OBJECT

public:
    explicit logos(QWidget *parent = nullptr);
    ~logos();

private slots:
    void on_pushButton_clicked();

private:
    Ui::logos *ui;
    Main_page * page_main;
};

#endif // LOGOS_H
