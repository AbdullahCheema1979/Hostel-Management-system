#include "main_page.h"
#include "ui_main_page.h"

Main_page::Main_page(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Main_page)
{
    ui->setupUi(this);
    this->setStyleSheet("background-color:#D5DDE2;");




}

Main_page::~Main_page()
{
    delete ui;
}

void Main_page::on_pushButton_clicked()
{
    hide();
    sign_admin = new admin_signup(this);
    sign_admin->show();

}


void Main_page::on_pushButton_2_clicked()
{
    hide();
    login_admin = new admin_login(this);
    login_admin->show();
}


void Main_page::on_pushButton_4_clicked()
{
    hide();
    signup_user = new user_signup(this);
    signup_user->show();
}


void Main_page::on_pushButton_3_clicked()
{
    hide();
    login_user = new user_login(this);
    login_user->show();

}

