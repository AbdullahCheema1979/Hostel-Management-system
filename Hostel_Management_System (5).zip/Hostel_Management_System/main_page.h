#ifndef MAIN_PAGE_H
#define MAIN_PAGE_H
#include "admin_signup.h"
#include "admin_login.h"
#include "user_login.h"
#include "user_signup.h"


#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class Main_page;
}
QT_END_NAMESPACE

class Main_page : public QMainWindow
{
    Q_OBJECT

public:
    Main_page(QWidget *parent = nullptr);
    ~Main_page();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::Main_page *ui;
    admin_signup * sign_admin;
    admin_login * login_admin;
    user_login * login_user;
    user_signup * signup_user;
};
#endif // MAIN_PAGE_H
