#include "user_dashboard.h"
#include "ui_user_dashboard.h"
#include <QMessageBox>
#include"user_view_mealmenu.h"
#include"logos.h"

user_dashboard::user_dashboard(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::user_dashboard)
{
    ui->setupUi(this);
       this->setStyleSheet("background-color:#36454F;");

}

user_dashboard::~user_dashboard()
{
    delete ui;
}

void user_dashboard::on_pushButton_clicked()
{
    hide();
    user_complains = new user_submit_complains(this);
    user_complains->show();
}


void user_dashboard::on_pushButton_3_clicked()
{

    QMessageBox::StandardButton reply;

    reply = QMessageBox::question(this,"Message","Do you really want to logout?",QMessageBox::Yes | QMessageBox::No);


    if (reply == QMessageBox::Yes) {
        log =new logos(this);
        log->show();
        this->close();


    } else {
        return;
    }
}


void user_dashboard::on_pushButton_2_clicked()
{   hide();
    meal = new user_view_mealmenu(this);
    meal->show();



}

