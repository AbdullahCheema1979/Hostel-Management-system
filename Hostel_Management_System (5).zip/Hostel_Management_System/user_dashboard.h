#ifndef USER_DASHBOARD_H
#define USER_DASHBOARD_H
#include "user_submit_complains.h"
#include"user_view_mealmenu.h"


#include <QMainWindow>
class logos;

namespace Ui {
class user_dashboard;
class user_view_mealmenu;
}

class user_dashboard : public QMainWindow
{
    Q_OBJECT

public:
    explicit user_dashboard(QWidget *parent = nullptr);
    ~user_dashboard();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::user_dashboard *ui;
    user_submit_complains * user_complains;
    user_view_mealmenu * meal;
    logos *log;
};

#endif // USER_DASHBOARD_H
