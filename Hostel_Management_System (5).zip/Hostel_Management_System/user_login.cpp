#include "user_login.h"
#include "ui_user_login.h"
#include<QFile>
#include<QTextStream>
#include<QDebug>
#include<QMessageBox>

user_login::user_login(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::user_login)
{
    ui->setupUi(this);
        this->setStyleSheet("background-color:#36454F;");
}

user_login::~user_login()
{
    delete ui;
}

void user_login::on_pushButton_clicked()
{

    bool found = false;
    QString username=ui->uname->text();
    QString upass=ui->password->text();
    QFile file("C:/Users/abdul/OneDrive/Desktop/Hostel_Management_System/usersignup.txt");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QMessageBox::warning(this,"Error","Cannot open file!");
        return;
    }
    else
    {
        QTextStream in(&file);
        while(!in.atEnd())
        {
            QString line = in.readLine();
            QStringList data = line.split("|");
            if(data.size() >=4)
            {
                QString unam=data[0];
                QString nic=data[1];
                QString pass=data[2];
                QString rpass=data[3];
                if((nic == username && pass == upass))
                {
                    found =true;
                    break;
                }







            }

        }
    }
    if(found)
    {
        // QMessageBox::information(this,"login","login successful");
        hide();
        dashboard_user = new user_dashboard(this);
        dashboard_user ->show();
    }
    else
    {
        QMessageBox::information(this,"Error","Invalid details");
    }

}

