#ifndef USER_LOGIN_H
#define USER_LOGIN_H
#include "user_dashboard.h"

#include <QMainWindow>

namespace Ui {
class user_login;
}

class user_login : public QMainWindow
{
    Q_OBJECT

public:
    explicit user_login(QWidget *parent = nullptr);
    ~user_login();

private slots:
    void on_pushButton_clicked();

private:
    Ui::user_login *ui;
    user_dashboard * dashboard_user;
};

#endif // USER_LOGIN_H
