#include "user_signup.h"
#include "ui_user_signup.h"
#include<QMessageBox>
#include<QFile>
#include<QTextStream>
#include<QDebug>

user_signup::user_signup(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::user_signup)
{
    ui->setupUi(this);
       this->setStyleSheet("background-color:#36454F;");
}

user_signup::~user_signup()
{
    delete ui;
}

void user_signup::on_pushButton_clicked()
{

    QString uname = ui->name->text();
    QString ncnic = ui->cnic->text();
    QString pass = ui->password->text();
    QString rpass = ui->repassword->text();
    if(pass != rpass)
    {
        QMessageBox::warning(this,"Password Error","Password or repassword doesnot match");
    }
    else
    {
        QFile file("C:/Users/abdul/OneDrive/Desktop/Hostel_Management_System/usersignup.txt");
        if(!file.open(QIODevice::Append | QIODevice::Text))
        {
            QMessageBox::warning(this,"Error","Cannt open file");
            return;
        }
        else
        {
            QTextStream out(&file);
            out<<uname<<"|"<<ncnic<<"|"<<pass<<"|"<<rpass<<"\n";
            file.close();
            QMessageBox::information(this,"Success","Signup successfull");

            login_user = new user_login(this);
            login_user->show();
        }

    }




}

