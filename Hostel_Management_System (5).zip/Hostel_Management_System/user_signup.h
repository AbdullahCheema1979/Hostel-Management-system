#ifndef USER_SIGNUP_H
#define USER_SIGNUP_H
#include"user_login.h"
#include <QMainWindow>

namespace Ui {
class user_signup;
}

class user_signup : public QMainWindow
{
    Q_OBJECT

public:
    explicit user_signup(QWidget *parent = nullptr);
    ~user_signup();

private slots:
    void on_pushButton_clicked();

private:
    Ui::user_signup *ui;
    user_login * login_user;
};

#endif // USER_SIGNUP_H
