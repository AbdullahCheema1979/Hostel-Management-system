#include "user_submit_complains.h"
#include "ui_user_submit_complains.h"
#include<QMessageBox>
#include<QFile>
#include<QTextStream>
#include<QDebug>
#include"user_dashboard.h"


user_submit_complains::user_submit_complains(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::user_submit_complains)
{
    ui->setupUi(this);
       this->setStyleSheet("background-color:#36454F;");
}

user_submit_complains::~user_submit_complains()
{
    delete ui;
}

void user_submit_complains::on_pushButton_clicked()
{
    QString comp=ui->textEdit->toPlainText();
    if(comp.length() <1)
    {
        QMessageBox::warning(this,"Error","Complain couldnot be empty");
    }
    else
    {
    QFile file("C:/Users/abdul/OneDrive/Desktop/Hostel_Management_System/complains.txt");
    if(!file.open(QIODevice::Append | QIODevice::Text))
    {
        QMessageBox::warning(this,"Error","Cannot open file");
        return;
    }
    QTextStream out(&file);
    out<<comp <<"\n";
    file.close();
    QMessageBox::information(this,"sucess","complain submitted sucessful");


    }

}


void user_submit_complains::on_pushButton_2_clicked()
{hide();
    userdesh = new user_dashboard(this);
    userdesh->show();
}

