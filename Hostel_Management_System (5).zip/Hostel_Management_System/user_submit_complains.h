#ifndef USER_SUBMIT_COMPLAINS_H
#define USER_SUBMIT_COMPLAINS_H

#include <QMainWindow>
class user_dashboard;
namespace Ui {
class user_submit_complains;
}

class user_submit_complains : public QMainWindow
{
    Q_OBJECT

public:
    explicit user_submit_complains(QWidget *parent = nullptr);
    ~user_submit_complains();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::user_submit_complains *ui;
    user_dashboard * userdesh;
};

#endif // USER_SUBMIT_COMPLAINS_H
