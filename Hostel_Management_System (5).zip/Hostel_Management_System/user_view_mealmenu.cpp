#include "user_view_mealmenu.h"
#include "ui_user_view_mealmenu.h"
#include<QMessageBox>
#include<QObject>
#include<QFile>
#include<QTextStream>
#include<QDebug>
#include<QWidget>
#include<user_dashboard.h>
#include<QTableWidget>

user_view_mealmenu::user_view_mealmenu(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::user_view_mealmenu)
{
    ui->setupUi(this);
       this->setStyleSheet("background-color:#36454F;");
}

user_view_mealmenu::~user_view_mealmenu()
{
    delete ui;
}



void user_view_mealmenu::on_pushButton_clicked()
{
    QFile file("C:/Users/abdul/OneDrive/Desktop/Hostel_Management_System/meal.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot open meal file");
        return;
    }

    QTextStream in(&file);
    QStringList lines;
    while (!in.atEnd()) {
        QString line = in.readLine();
        if (!line.isEmpty())
            lines.append(line);
    }
    file.close();


    ui->tableWidget->setRowCount(lines.size());
    ui->tableWidget->setColumnCount(1);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() << "Menu");


    for (int i = 0; i < lines.size(); ++i) {
        ui->tableWidget->setItem(i, 0, new QTableWidgetItem(lines[i]));
    }

    }




void user_view_mealmenu::on_pushButton_2_clicked()
{
    hide();
    user = new user_dashboard(this);
    user->show();

}








