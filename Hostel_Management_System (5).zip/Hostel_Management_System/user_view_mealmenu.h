#ifndef USER_VIEW_MEALMENU_H
#define USER_VIEW_MEALMENU_H

#include <QMainWindow>
class user_dashboard;

namespace Ui {
class user_view_mealmenu;
}

class user_view_mealmenu : public QMainWindow
{
    Q_OBJECT

public:
    explicit user_view_mealmenu(QWidget *parent = nullptr);
    ~user_view_mealmenu();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_tableWidget_cellActivated(int row, int column);

private:
    Ui::user_view_mealmenu *ui;
    user_dashboard * user;
};

#endif // USER_VIEW_MEALMENU_H
